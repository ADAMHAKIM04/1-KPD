<?php
	include 'header.php';
?>

<form action="search.php" method="POST">
	<input type="text" name="search" placeholder="Search">
	<button type="submit" name="submit-search">Search</button>
</form>

<h1>Front page</h1>
<h2>All user</h2>

<div class="user-container">
	<?php
		$sql = "SELECT * FROM users";
		$result = mysqli_query($mysqli, $sql);
		$queryResults = mysqli_num_rows($result);

		if($queryResults > 0) {
			while ($row = mysqli_fetch_assoc($result)) {
				echo "<div class='.user-box'>
					<h3>".$row['id']."</h3>
					<h3>".$row['name']."</h3>
					<h3>".$row['email']."</h3>
					<h3>".$row['mobile']."</h3>
				</div>";
			}
		}
	?>
</div>

</body>
</html>