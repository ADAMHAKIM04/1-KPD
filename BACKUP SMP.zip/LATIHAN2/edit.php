<?php
// sambungkan fail ini dengan file config
include_once("config.php");
 
// periksa sama ada telah submit dan terus ke home page
if(isset($_POST['update']))
{	
	$id = $_POST['id'];
	
	$name=$_POST['name'];
	$mobile=$_POST['mobile'];
	$email=$_POST['email'];
		
	// update user data
	$result = mysqli_query($mysqli, "UPDATE users SET name='$name',email='$email',mobile='$mobile' WHERE id=$id");
	
	// Redirect to homepage to display updated user in list
	header("Location: index.php");
}
?>
<?php
// paparkan data user yang dipilih menggunakan id
$id = $_GET['id'];
 
// mengambil data user berdasarkan id
$result = mysqli_query($mysqli, "SELECT * FROM users WHERE id=$id");
 
while($user_data = mysqli_fetch_array($result))
{
	$name = $user_data['name'];
	$email = $user_data['email'];
	$mobile = $user_data['mobile'];
}
?>
<html>
<head>	
	<title>Edit User Data</title>
	<style type="text/css">

    body{
        background: url(background.jpg);
    }
    .header{
        background-color: lightgreen;
        border: 5px solid green;
        overflow: hidden;      
    }
    .header a{
        text-decoration: none;
        color: black;
        padding: 12px;
        display: block;
        float: left;
    }
    .header a:hover{
        background-color: red;
        color: white;
    }
    .content{
        background-color: lightblue;
        border: 5px solid blue;
        padding: 20px;
    }
    .footer {
        background-color: red; 
        border: 5px solid black;
    }
    
    </style>
</head>
 
<body>
	<div class="header">
	<a href="index.php">Home</a>
	<br/><br/>
	</div>
	
	<div class="content">
	<form name="update_user" method="post" action="edit.php">
		<table border="0">
			<tr> 
				<td>Name</td>
				<td><input type="text" name="name" value=<?php echo $name;?>></td>
			</tr>
			<tr> 
				<td>Email</td>
				<td><input type="text" name="email" value=<?php echo $email;?>></td>
			</tr>
			<tr> 
				<td>Mobile</td>
				<td><input type="text" name="mobile" value=<?php echo $mobile;?>></td>
			</tr>
			<tr>
				<td><input type="hidden" name="id" value=<?php echo $_GET['id'];?>></td>
				<td><input type="submit" name="update" value="Update"></td>
			</tr>
		</table>
	</form></div>
<!--footer-->
    <div class="footer">
        <table width="95%">
            <tr>
                <td><center> KV PERD &copy; LUKMAN HAKIM 2020</center></td>
            </tr>
        </table>
     </div>
<!--footer-->
</body>
</html>