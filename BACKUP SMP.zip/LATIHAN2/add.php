<html>
<head>
	<title>Tambah Users</title>
	<style type="text/css">

    body{
        background: url(background.jpg);
    }
    .header{
        background-color: lightgreen;
        border: 5px solid green;
        overflow: hidden;      
    }
    .header a{
        text-decoration: none;
        color: black;
        padding: 12px;
        display: block;
        float: left;
    }
    .header a:hover{
        background-color: red;
        color: white;
    }
    .content{
        background-color: lightblue;
        border: 5px solid blue;
        padding: 20px;
    }
    .php{
    	background-color: yellow;
    	border: 5px solid orange;
    }
    .footer {
        background-color: red; 
        border: 5px solid black;
    }
    
    </style>
</head>
 
<body>
	<div class="header">
	<a href="index.php">Pergi Ke Pangkalan Data</a>
	<br/><br/>
 	</div>

 	<div class="content">
	<form action="add.php" method="post" name="form1">
		<table width="25%" border="0">
			<tr> 
				<td>Name</td>
				<td><input type="text" name="name"></td>
			</tr>
			<tr> 
				<td>Email</td>
				<td><input type="text" name="email"></td>
			</tr>
			<tr> 
				<td>Mobile</td>
				<td><input type="text" name="mobile"></td>
			</tr>
			<tr> 
				<td></td>
				<td><input type="submit" name="Submit" value="Add"></td>
			</tr>
		</table>
	</form></div>
	<div class="php">
	<?php
 
	// Check Jika form dihantar, masukkan data form ke dalam table user.
	if(isset($_POST['Submit'])) {
		$name = $_POST['name'];
		$email = $_POST['email'];
		$mobile = $_POST['mobile'];
		
		// buat sambungan database menggunakan gile config
		include_once("config.php");
				
		// masukkan data users dalam table
		$result = mysqli_query($mysqli, "INSERT INTO users(name,email,mobile) VALUES('$name','$email','$mobile')");
		
		// tunjuk kan mesej jika berjaya
		echo "User Berjaya Ditambah. <a href='view.php'>Lihat User</a>";
	}
	?></div>
<!--footer-->
    <div class="footer">
        <table width="95%">
            <tr>
                <td><center> KV PERD &copy; LUKMAN HAKIM 2020</center></td>
            </tr>
        </table>
     </div>
<!--footer-->
</body>
</html>