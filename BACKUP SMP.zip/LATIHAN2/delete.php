<?php
// sambungkan fail ini dengan file config
include_once("config.php");
 
// Guntuk mengistiharkan id
$id = $_GET['id'];
 
// padam data user dengan menggunakan id
$result = mysqli_query($mysqli, "DELETE FROM users WHERE id=$id");
 
// selepas selesai delete akan pergi ke fail index
header("Location:index.php");
?>