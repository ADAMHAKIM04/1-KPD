<?php
	include 'header.php';
?>

<h1>Search page</h1>

<div class="user-container">
<?php
	if (isset($_POST['submit-search'])) {
		$search = mysqli_real_escape_string($mysqli, $_POST['search']);
		$sql = "SELECT * FROM users WHERE id LIKE '%$search%' OR name LIKE '%$search%' OR email LIKE '%$search%' OR mobile LIKE '%$search%'";
		$result = mysqli_query($mysqli, $sql);
		$queryResult = mysqli_num_rows($result);

		echo "There are ".$queryResult." results!";

		if ($queryResult > 0) {
			while ($row = mysqli_fetch_assoc($result)) {
				echo "<a href='user.php?id=".$row['id']."&name=".$row['name']."'><div class='.user-box'>
				<table>
					<h3>".$row['id']."</h3>
					<h3>".$row['name']."</h3>
					<h3>".$row['email']."</h3>
					<h3>".$row['mobile']."</h3>
				</div></a>";
			}
		} else {
			echo "There are no results matching your search";
		}
	}
?>
</div>