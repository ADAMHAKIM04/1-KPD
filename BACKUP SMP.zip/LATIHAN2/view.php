<?php
// buat sambungan database menggunakan file config
include_once("config.php");
 
// ambik semua data user dari database
$result = mysqli_query($mysqli, "SELECT * FROM users ORDER BY id DESC");
?>
 
<html>
<head>    
    <title>User Page</title>
    <style type="text/css">

    body{
        background: url(background.jpg);
    }
    .header{
        background-color: lightgreen;
        border: 5px solid green;
        overflow: hidden;      
    }
    .header a{
        text-decoration: none;
        color: black;
        padding: 12px;
        display: block;
        float: left;
    }
    .header a:hover{
        background-color: red;
        color: white;
    }
    .content{
        background-color: lightblue;
        border: 5px solid blue;
        padding: 20px;
    }
    .th{
        background-color: yellow;
    }
    * {
        box-sizing: border-box;
    }

        /* Style the search field */
    form.example input[type=text] {
        padding: 10px;
        font-size: 17px;
        border: 1px solid grey;
        float: center;
        width: 60%;
        background: #f1f1f1;
    }

    /* Style the submit button */
    form.example button {
        float: center;
        width: 10%;
        padding: 10px;
        background: #2196F3;
        color: white;
        font-size: 17px;
        border: 1px solid grey;
        cursor: pointer;
    }

    form.example button:hover {
        background: #0b7dda;
    }

    /* Clear floats */
    form.example::after {
        content: "";
        clear: both;
        display: table;
    }
    .search{
        background-color: grey;
        border: 5px solid black;
        padding: 5px;
    }
    .footer {
        background-color: red; 
        border: 5px solid black;
    }

    </style>
</head>
 
<body>
    <div class="search">

    <form action="search.php" method="POST">
        <input type="text" name="search" placeholder="Search">
        <button type="submit" name="submit-search">Search</button>
    </form>

    </div>

<div class="header">
<a href="add.php">Tambah User Baru</a><br/><br/>
</div>
<div class="content">
<center>
    <table width='95%' border=1>
    <tr>
        <th class="th">Name</th> 
        <th class="th">Mobile</th>
        <th class="th">Email</th> 
    </tr>
    <?php  
    while($user_data = mysqli_fetch_array($result)) {         
        echo "<tr>";
        echo "<td>".$user_data['name']."</td>";
        echo "<td>".$user_data['mobile']."</td>";
        echo "<td>".$user_data['email']."</td>";     
    }
    ?>
    </table>
</div>
<!--footer-->
    <div class="footer">
        <table width="95%">
            <tr>
                <td><center> KV PERD &copy; LUKMAN HAKIM 2020</center></td>
            </tr>
        </table>
     </div>
<!--footer-->
</center>
</div>
</body>
</html>