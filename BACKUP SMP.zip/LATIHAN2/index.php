<?php
// buat sambungan database menggunakan file config
include_once("config.php");
 
// ambik semua data user dari database
$result = mysqli_query($mysqli, "SELECT * FROM users ORDER BY id DESC");
?>
 
<html>
<head>    
    <title>Homepage</title>
    <style type="text/css">

    body{
        background: url(background.jpg);
    }
    .header{
        background-color: lightgreen;
        border: 5px solid green;
        overflow: hidden;      
    }
    .header a{
        text-decoration: none;
        color: black;
        padding: 12px;
        display: block;
        float: left;
    }
    .header a:hover{
        background-color: red;
        color: white;
    }
    .content{
        background-color: lightblue;
        border: 5px solid blue;
        padding: 20px;
    }
    .th{
        background-color: yellow;
    }
    .footer {
        background-color: red; 
        border: 5px solid black;
    }

    </style>
</head>
 
<body>
<div class="header">
<a href="add.php">Tambah User Baru</a><br/><br/>
</div>
<div class="content">
<center>
    <table width='95%' border=1>
    <tr>
        <th class="th">Name</th> 
        <th class="th">Mobile</th> 
        <th class="th">Email</th> 
        <th class="th">Action</th>
    </tr>
    <?php  
    while($user_data = mysqli_fetch_array($result)) {         
        echo "<tr>";
        echo "<td>".$user_data['name']."</td>";
        echo "<td>".$user_data['mobile']."</td>";
        echo "<td>".$user_data['email']."</td>";    
        echo "<td><a href='edit.php?id=$user_data[id]'>Edit</a> | <a href='delete.php?id=$user_data[id]'>Delete</a></td></tr>";        
    }
    ?>
    </table>
</div>
<!--footer-->
    <div class="footer">
        <table width="95%">
            <tr>
                <td><center> KV PERD &copy; LUKMAN HAKIM 2020</center></td>
            </tr>
        </table>
     </div>
<!--footer-->
</center>

</body>
</html>